import requests
import json
post_url = "https://hooks.slack.com/services/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https://hoo"

def post_slack(name, text):
    requests.post(
        post_url,
        data=json.dumps(
            {"text": text,
             "username": name,
             "icon_emoji": ":python:"}))

post_slack("自動ポスト", "これはテストです")
"""
def lambda_handler(event, context):
    # TODO implement
    return { 'statusCode': 200, 'body': json.dumps(event) }
"""
